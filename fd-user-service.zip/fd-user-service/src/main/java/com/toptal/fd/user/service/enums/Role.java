package com.toptal.fd.user.service.enums;

public enum Role {
    CUSTOMER,
    OWNER,
    ADMIN
}