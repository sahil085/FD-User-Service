package com.toptal.fd.user.service.service;

import com.toptal.fd.user.service.dto.AuthRequest;
import com.toptal.fd.user.service.dto.AuthResponse;
import com.toptal.fd.user.service.enums.Role;
import com.toptal.fd.user.service.exception.InvalidCredentialsException;
import com.toptal.fd.user.service.exception.UserAlreadyExistsException;
import com.toptal.fd.user.service.exception.UserNotFoundException;
import com.toptal.fd.user.service.repository.UserRepository;
import com.toptal.fd.user.service.entity.User;
import com.toptal.fd.user.service.response.ApiResponse;
import com.toptal.fd.user.service.security.JwtUtil;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @PostConstruct
    public void createAdmin() {

        log.info("Initializing default admin user");

        if (userRepository.findByEmail("admin@food.com").isEmpty()) {

            log.debug("Admin user not found, creating default admin");

            User admin = User.builder()
                    .email("admin@food.com")
                    .password(passwordEncoder.encode("admin123"))
                    .role(Role.ADMIN)
                    .blocked(false)
                    .build();

            userRepository.save(admin);

            log.info("Default admin user created successfully");
        } else {
            log.debug("Admin user already exists, skipping creation");
        }
    }

    public ApiResponse<String> registerCustomer(AuthRequest request) {

        log.info("Registering new customer");
        log.debug("Customer registration request for email={}", request.getEmail());

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            log.warn("Registration failed: user already exists with email={}", request.getEmail());
            throw new UserAlreadyExistsException("User already exists with this email");
        }

        User user = User.builder()
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.CUSTOMER)
                .build();

        userRepository.save(user);

        log.info("Customer registered successfully for email={}", request.getEmail());

        return ApiResponse.success("Customer registered successfully", null, HttpStatus.CREATED.value());
    }


    public ApiResponse<AuthResponse> login(AuthRequest request) {

        log.info("Processing login request");
        log.debug("Login attempt for email={}", request.getEmail());

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.warn("Login failed: user not found for email={}", request.getEmail());
                    return new UserNotFoundException("User not found");
                });

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.warn("Login failed: invalid credentials for email={}", request.getEmail());
            throw new InvalidCredentialsException("Invalid credentials");
        }

        log.debug("Credentials validated for email={}", request.getEmail());

        String token = jwtUtil.generateToken(
                user.getEmail(),
                user.getRole().name()
        );

        log.info("Login successful for email={}", request.getEmail());

        return ApiResponse.success("Login success", new AuthResponse(token), HttpStatus.OK.value());
    }
}