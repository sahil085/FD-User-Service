package com.toptal.fd.user.service.dto;

import com.toptal.fd.user.service.enums.Role;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDto {

    private Long id;

    private String email;

    private Role role;

    private boolean blocked = false;
}
