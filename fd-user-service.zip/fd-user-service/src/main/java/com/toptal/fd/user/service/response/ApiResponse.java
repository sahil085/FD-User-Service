package com.toptal.fd.user.service.response;

import com.toptal.fd.user.service.constant.AppConstants;
import lombok.*;
import org.slf4j.MDC;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApiResponse<T> {

    private int status;
    private String message;
    private T data;
    private String correlationId;
    private LocalDateTime timestamp;

    public static <T> ApiResponse<T> success(String message, T data, int status) {
        return ApiResponse.<T>builder()
                .status(status)
                .message(message)
                .data(data)
                .correlationId(MDC.get(AppConstants.CORRELATION_ID))
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static <T> ApiResponse<T> error(String message, int status) {
        return ApiResponse.<T>builder()
                .status(status)
                .message(message)
                .data(null)
                .correlationId(MDC.get(AppConstants.CORRELATION_ID))
                .timestamp(LocalDateTime.now())
                .build();
    }

}