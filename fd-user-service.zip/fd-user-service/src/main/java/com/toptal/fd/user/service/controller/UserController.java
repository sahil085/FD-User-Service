package com.toptal.fd.user.service.controller;

import com.toptal.fd.user.service.dto.UserDto;
import com.toptal.fd.user.service.dto.AuthRequest;
import com.toptal.fd.user.service.response.ApiResponse;
import com.toptal.fd.user.service.response.UserResponse;
import com.toptal.fd.user.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final UserService userService;

    @GetMapping("/{email}")
    public ResponseEntity<ApiResponse<UserDto>> getUser(@PathVariable String email) {

        log.info("Received request to fetch user details");
        log.debug("Fetching user with email={}", email);

        ApiResponse<UserDto> response = userService.getUserByEmail(email);

        log.info("User fetch completed for email={}", email);

        return ResponseEntity.ok(response);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @PostMapping("/register/owner")
    public ResponseEntity<ApiResponse<UserResponse>> registerOwner(@RequestBody AuthRequest request) {

        log.info("Received request to register owner");
        log.debug("Owner registration request for email={}", request.getEmail());

        ApiResponse<UserResponse> response = userService.registerOwner(request);

        log.info("Owner registration completed for email={}", request.getEmail());

        return ResponseEntity.ok(response);
    }
}