package com.toptal.fd.user.service.controller;

import com.toptal.fd.user.service.dto.AuthRequest;
import com.toptal.fd.user.service.dto.AuthResponse;
import com.toptal.fd.user.service.response.ApiResponse;
import com.toptal.fd.user.service.service.AuthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@Slf4j
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register/customer")
    public ResponseEntity<ApiResponse<String>> registerCustomer(@RequestBody AuthRequest request) {

        log.info("Received request for customer registration");
        log.debug("Register request details: email={}", request.getEmail());

        ApiResponse<String> response = authService.registerCustomer(request);

        log.info("Customer registration completed for email={}", request.getEmail());

        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@RequestBody AuthRequest request) {

        log.info("Received login request");
        log.debug("Login request for email={}", request.getEmail());

        ApiResponse<AuthResponse> response = authService.login(request);

        log.info("Login process completed for email={}", request.getEmail());

        return ResponseEntity.ok(response);
    }
}