package com.toptal.fd.user.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing(auditorAwareRef = "auditorProvider")
public class FdUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FdUserServiceApplication.class, args);
	}

}
