package com.toptal.fd.user.service.service;

import com.toptal.fd.user.service.dto.AuthRequest;
import com.toptal.fd.user.service.dto.UserDto;
import com.toptal.fd.user.service.enums.Role;
import com.toptal.fd.user.service.exception.UserAlreadyExistsException;
import com.toptal.fd.user.service.exception.UserNotFoundException;
import com.toptal.fd.user.service.mapper.UserMapper;
import com.toptal.fd.user.service.repository.UserRepository;
import com.toptal.fd.user.service.entity.User;
import com.toptal.fd.user.service.response.ApiResponse;
import com.toptal.fd.user.service.response.UserResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;


    public ApiResponse<UserDto> getUserByEmail(String email) {

        log.info("Fetching user by email");
        log.debug("Fetching user details for email={}", email);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> {
                    log.warn("User not found for email={}", email);
                    return new UserNotFoundException("User not found");
                });

        log.info("User found for email={}", email);

        return ApiResponse.success("User fetch by email successfully", UserDto.builder()
                .email(user.getEmail())
                .blocked(user.isBlocked())
                .role(user.getRole())
                .id(user.getId())
                .build(), HttpStatus.OK.value());
    }

    public ApiResponse<UserResponse> registerOwner(AuthRequest request) {

        log.info("Registering new owner");
        log.debug("Owner registration request for email={}", request.getEmail());

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            log.warn("Owner registration failed: user already exists with email={}", request.getEmail());
            throw new UserAlreadyExistsException("User already exists");
        }

        User user = User.builder()
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.OWNER)
                .build();

        userRepository.save(user);

        log.info("Owner registered successfully for email={}", request.getEmail());

        return ApiResponse.success("Owner registered successfully", userMapper.toResponse(user), HttpStatus.CREATED.value());
    }

}