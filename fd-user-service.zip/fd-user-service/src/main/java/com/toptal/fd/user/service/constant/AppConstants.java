package com.toptal.fd.user.service.constant;

public class AppConstants {

    public static final String CORRELATION_ID = "X-Correlation-Id";
}
