package com.toptal.fd.user.service.mapper;

import com.toptal.fd.user.service.entity.User;
import com.toptal.fd.user.service.response.UserResponse;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    public UserResponse toResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .email(user.getEmail())
                .role(user.getRole().name())
                .build();
    }

}
