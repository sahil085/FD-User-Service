package com.toptal.fd.user.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FdUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
